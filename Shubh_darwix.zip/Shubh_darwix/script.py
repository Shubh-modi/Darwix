
import sys
import json
import textwrap
from typing import List, Dict, Any

try:
    from groq import Groq
except Exception:
    Groq = None

    
#set your api key here 
api_key = "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"

PEP8_LINK = "https://peps.python.org/pep-0008/"
COMPLEXITY_DOC = "https://en.wikipedia.org/wiki/Time_complexity"

SEVERITY_KEYWORDS = {
    "security": ["vulnerable", "injection", "unsafe", "race", "leak"],
    "performance": ["inefficient", "slow", "optimize", "O(", "loop"],
    "readability": ["confusing", "variable", "name", "style", "messy"],
    "bug": ["wrong", "bug", "fails", "error"],
}

def detect_severity(comment: str) -> str:
    c = comment.lower()
    hits = {k: any(kword in c for kword in kws) for k, kws in SEVERITY_KEYWORDS.items()}
    if hits.get("security"): return "high"
    if hits.get("bug"): return "high"
    if hits.get("performance"): return "medium"
    if hits.get("readability"): return "low"
    # default severity based on punctuation/tones
    if "!" in comment or "always" in c: return "medium"
    return "low"

def build_prompt(code_snippet: str, comment: str, severity: str) -> str:
    """
    Build a clear instruction for the LLM to produce the three required sections.
    """
    tone = {
        "high": "firm but compassionate — prioritize clarity and professional guidance.",
        "medium": "supportive and explanatory.",
        "low": "very gentle, encouraging, and educational."
    }.get(severity, "supportive and explanatory.")

    prompt = f"""
You are an expert senior developer and a patient mentor. 
Given the code and a direct review comment, produce a Markdown fragment that contains exactly three sections:
1) Positive Rephrasing: a single sentence that reframes the comment in a gentle, constructive way.
2) The 'Why': a 2-4 sentence explanation of the underlying principle (performance, readability, convention etc.).
3) Suggested Improvement: A runnable code example showing the fix. Put the code in a fenced code block and label the language.

Tone instructions: {tone}

Provide also one relevant external link (PEP8 or algorithmic complexity or style guide) when applicable.

Inputs:
---CODE_SNIPPET---
{code_snippet}
---REVIEW_COMMENT---
{comment}
---END---
Respond only with the Markdown fragment (no extra headings).
"""
    return textwrap.dedent(prompt) 

def call_groq(prompt: str) -> str:
    """
    Call Groq LLM using the official client API.
    """
    if not api_key or Groq is None:
        raise RuntimeError("Groq client not configured. Set GROQ_API_KEY and install `groq`.")

    client = Groq(api_key=api_key)

    try:
        resp = client.chat.completions.create(
            model="llama-3.1-8b-instant",  # or llama-3.1-70b if you want bigger
            messages=[
                {"role": "system", "content": "You are an empathetic senior code reviewer."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.7,
        )
        return resp.choices[0].message.content
    except Exception as e:
        raise RuntimeError(f"Groq API call failed: {e}")

def local_template(code_snippet: str, comment: str, severity: str) -> str:
    """
    If Groq isn't available, produce a deterministic helpful template so the demo still works offline.
    """
    # Heuristic detections
    why = "This helps follow common best practices to improve code quality."
    link = PEP8_LINK
    if "ineff" in comment.lower() or "loop" in comment.lower():
        why = ("Iterating inefficiently can hurt performance when the input grows. "
               "Combining operations or using comprehensions can be both cleaner and faster.")
        link = COMPLEXITY_DOC
    elif "name" in comment.lower() or "variable" in comment.lower():
        why = ("Meaningful variable names improve readability and make maintenance easier. "
               "Clear names communicate intent without needing additional comments.")
        link = PEP8_LINK
    elif "true" in comment.lower() or "boolean" in comment.lower():
        why = ("Redundant boolean comparisons reduce readability. "
               "Truthiness checks are more idiomatic in Python.")
        link = PEP8_LINK

    positive = f"Nice idea — here's a small suggestion to improve this area for clarity and maintainability."
    suggested_code = "```python\n# Example improvement here\n```\n"

    # Try to craft a small suggested improvement for common Python patterns mentioned in the hack prompt
    if "== true" in comment.lower() or "boolean comparison" in comment.lower():
        suggested_code = textwrap.dedent("""\
        ```python
        def get_active_users(users):
            return [user for user in users if user.is_active and user.profile_complete]
        ```""")
    elif "variable" in comment.lower() and "u" in comment.lower():
        suggested_code = textwrap.dedent("""\
        ```python
        def get_active_users(users):
            return [user for user in users if user.is_active and user.profile_complete]
        ```""")
    elif "loop" in comment.lower() or "ineffic" in comment.lower():
        suggested_code = textwrap.dedent("""\
        ```python
        def get_active_users(users):
            # single-pass, list comprehension approach
            return [user for user in users if user.is_active and user.profile_complete]
        ```""")
    else:
        suggested_code = textwrap.dedent(f"""\
        ```python
        # Suggestion placeholder: rewrite according to the comment
        {code_snippet}
        ```""")

    md = textwrap.dedent(f"""\
    * **Positive Rephrasing:** {positive}
    * **The 'Why':** {why}
    * **Suggested Improvement:**\n{suggested_code}\n* **Reference:** {link}
    """)
    return md

def generate_markdown_report(data: Dict[str, Any]) -> str:
    code_snippet = data.get("code_snippet", "")
    comments: List[str] = data.get("review_comments", [])
    parts = []
    for comment in comments:
        severity = detect_severity(comment)
        prompt = build_prompt(code_snippet, comment, severity)

        # Try using Groq; if not available, fallback to local_template
        try:
            if Groq and api_key:
                print("Using Groq LLM for generation...")
                ai_out = call_groq(prompt)
                fragment = ai_out.strip()
            else:
                raise RuntimeError("Groq not configured, using local template.")
        except Exception as e:
            print(f"[Info] LLM unavailable or failed ({e}). Using local deterministic template.")
            fragment = local_template(code_snippet, comment, severity)

        header = f"---\n### Analysis of Comment: \"{comment}\"\n"
        parts.append(header + fragment)

    # Holistic summary
    summary = (
        "\n---\n"
        "## Holistic Summary\n\n"
        "Overall, the suggestions above aim to improve readability, performance, and adherence to "
        "Python conventions while being constructive and supportive. Keep iterating — small, clear changes "
        "will compound into a more maintainable codebase.\n"
    )

    # Optionally add resources
    resources = "\n**Helpful resources:**\n- PEP 8 — Python Style Guide: " + PEP8_LINK + "\n- Time Complexity: " + COMPLEXITY_DOC + "\n"

    markdown = "\n\n".join(parts) + summary + resources
    return markdown

def main():
    if len(sys.argv) < 3:
        print("Usage: python empathetic_reviewer.py input.json output.md")
        sys.exit(1)
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    report_md = generate_markdown_report(data)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(report_md)
    print(f"Generated report -> {output_path}")

if __name__ == "__main__":
    main()
